import org.redfx.strange.Program;
import org.redfx.strange.QuantumExecutionEnvironment;
import org.redfx.strange.Qubit;
import org.redfx.strange.Result;
import org.redfx.strange.Step;
import org.redfx.strange.gate.Hadamard;
import org.redfx.strange.gate.X;
import org.redfx.strange.local.SimpleQuantumExecutionEnvironment;

public class QRNG {

	public static void main(String[] args) {
		int numBits = 3;
		System.out.printf("number of bits: %d\n", numBits);

		long theRandomInt = 0;

		for (int i = 0; i < numBits; i++) {
			if (randomBit(args) > 0) {
				System.out.print("1");
				int contribution = (int) Math.pow(2, i);
				theRandomInt += contribution;
			} else {
				System.out.print("0");
			}
		}

		System.out.println();
		System.out.printf("Random %d bits is %x\n", numBits, theRandomInt);
	}

	public static int randomBit(String[] args) {
		QuantumExecutionEnvironment env = new SimpleQuantumExecutionEnvironment();
		Program p = new Program(1);

		Step step = new Step();
//		step.addGate(new X(0));
		step.addGate(new Hadamard(0));
		p.addStep(step);

		Result r = env.runProgram(p);
		Qubit[] qubits = r.getQubits();
		Qubit zero = qubits[0];
		int value = zero.measure();
//		System.out.println("Value = " + value);
		return value;

	}
}